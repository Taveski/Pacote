
package mapa;

import javax.swing.JOptionPane;

public class Exame {
    Paciente paciente;
    double valor;

    public Exame(Paciente paciente, double valor) {
        this.paciente = paciente;
        this.valor = valor;
    }

    public void classificarResultado() {
        
    }

    public void mostrarResultado() {
        String message = "Paciente: " + paciente.getNome() + "\nValor do exame: " + valor;
        JOptionPane.showMessageDialog(null, message, "Resultado de Exame", JOptionPane.INFORMATION_MESSAGE);
    }

    public static Exame criarExame() {
        String nomePaciente = JOptionPane.showInputDialog("Digite o nome do paciente:");
        String tipoSanguineo = JOptionPane.showInputDialog("Digite o tipo sanguíneo do paciente:");
        int anoNascimento = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de nascimento do paciente:"));
        double valorExame = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do exame:"));

        Paciente paciente = new Paciente(nomePaciente, tipoSanguineo, anoNascimento);
        return new Exame(paciente, valorExame);
    }

    public static void main(String[] args) {
        Exame novoExame = criarExame();
        novoExame.mostrarResultado();
    }
}