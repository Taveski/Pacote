
package mapa;

import javax.swing.JOptionPane;

class Colesterol extends Exame {
    private double ldlMgPerDl;
    private double hdlMgPerDl;
    private char risco;

    public Colesterol(Paciente paciente, double valor, double ldlMgPerDl, double hdlMgPerDl, char risco) {
        super(paciente, valor);
        this.ldlMgPerDl = ldlMgPerDl;
        this.hdlMgPerDl = hdlMgPerDl;
        this.risco = risco;
    }

    @Override
    public void classificarResultado() {
        int hdlLimit = (paciente.calcularIdade(2023) <= 19) ? 45 : 40;
        double ldlLimit;
        if (risco == 'B') {
            ldlLimit = 100;
        } else if (risco == 'M') {
            ldlLimit = 70;
        } else {
            ldlLimit = 50;
        }
        String hdlStatus = (hdlMgPerDl > hdlLimit) ? "BOM" : "BAIXO";
        String ldlStatus = (ldlMgPerDl < ldlLimit) ? "BOM" : "ALTO";

        String classification = "HDL: " + hdlStatus + " | LDL: " + ldlStatus;
        String message = "Paciente: " + paciente.getNome() + "\nValor do exame: " + valor;

        JOptionPane.showMessageDialog(null, classification, "Classificação de Colesterol", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, message, "Resultado de Exame - Colesterol", JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void mostrarResultado() {
        super.mostrarResultado();
        classificarResultado();
    }
}