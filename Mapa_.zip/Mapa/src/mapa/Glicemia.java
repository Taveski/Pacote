
package mapa;

import javax.swing.JOptionPane;
public class Glicemia extends Exame {
    private double glicoseMgPerDl;

    public Glicemia(Paciente paciente, double valor, double glicoseMgPerDl) {
        super(paciente, valor);
        this.glicoseMgPerDl = glicoseMgPerDl;
    }
    @Override
    public void classificarResultado() {
        String classification;
        if (glicoseMgPerDl < 100) {
            classification = "Normoglicemia";
        } else if (glicoseMgPerDl < 126) {
            classification = "Pré-diabetes";
        } else {
            classification = "Diabetes estabelecido";
        }
        JOptionPane.showMessageDialog(null, classification, "Classificação de Glicemia", JOptionPane.INFORMATION_MESSAGE);
    }

@Override
    public void mostrarResultado() {
        super.mostrarResultado();
        
 String message = "Paciente: " + paciente.getNome() + "\nValor do exame: " + valor;
        JOptionPane.showMessageDialog(null, message, "Resultado de Exame - Glicemia", JOptionPane.INFORMATION_MESSAGE);
        classificarResultado();
    }
}

