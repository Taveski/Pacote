
package mapa;

import javax.swing.JOptionPane;

public class Paciente {
    private String nome;
    private String tipoSanguineo;
    private int anoNascimento;

    public Paciente(String nome, String tipoSanguineo, int anoNascimento) {
        this.nome = nome;
        this.tipoSanguineo = tipoSanguineo;
        this.anoNascimento = anoNascimento;
    }

    public int calcularIdade(int anoAtual) {
        return anoAtual - anoNascimento;
    }

    public String getNome() {
        return nome;
    }

    public static Paciente criarPaciente() {
        String nome = JOptionPane.showInputDialog("Digite o nome do paciente:");
        String tipoSanguineo = JOptionPane.showInputDialog("Digite o tipo sanguíneo do paciente:");
        int anoNascimento = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de nascimento do paciente:"));

        return new Paciente(nome, tipoSanguineo, anoNascimento);
    }

    public static void main(String[] args) {
        Paciente novoPaciente = criarPaciente();
        System.out.println("Nome do paciente: " + novoPaciente.getNome());
        System.out.println("Idade: " + novoPaciente.calcularIdade(2023));
    }
}