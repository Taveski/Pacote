/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mapa;

/**
 *
 * @author User_Pc
 */
import javax.swing.JOptionPane;

public class Laboratorio {
    public static void main(String[] args) {
        String nomePaciente = JOptionPane.showInputDialog("Digite o nome do paciente:");
        String tipoSanguineo = JOptionPane.showInputDialog("Digite o tipo sanguíneo do paciente:");
        int anoNascimento = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de nascimento do paciente:"));

        Paciente paciente = new Paciente(nomePaciente, tipoSanguineo, anoNascimento);

        double valorGlicemia = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor da glicemia:"));
        double valorColesterol = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do colesterol:"));
        double valorTriglicerideos = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor dos triglicerídeos:"));

        Glicemia glicemia = new Glicemia(paciente, valorGlicemia, 90);
        Colesterol colesterol = new Colesterol(paciente, valorColesterol, 130, 50, 'A');
        Triglicerideos triglicerideos = new Triglicerideos(paciente, valorTriglicerideos, true);

        Exame[] exames = {glicemia, colesterol, triglicerideos};

        for (Exame exame : exames) {
            exame.mostrarResultado();
            System.out.println();
        }
    }
}


           