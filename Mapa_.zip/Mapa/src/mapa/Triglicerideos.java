
package mapa;

import javax.swing.JOptionPane;
public class Triglicerideos extends Exame {
    private final boolean jejum;

    public Triglicerideos(Paciente paciente, double valor, boolean jejum) {
        super(paciente, valor);
        this.jejum = jejum;
    }

    @Override
   public void classificarResultado() {
    int idade = paciente.calcularIdade(2023);
    int limit;
    if (idade <= 9) {
        limit = 75;
    } else if (idade <= 19) {
        limit = 90;
    } else {
        limit = 150;
    }
    String ageGroup = (idade <= 9) ? "De 0 a 9 anos" : (idade <= 19) ? "De 10 a 19 anos" : "Acima de 20 anos";
    String fastingStatus = (jejum ? "Com" : "Sem") + " Jejum";
    String classification = ageGroup + ", " + fastingStatus + ": " + (valor < limit ? "BOM" : "ALTO");
    
    String message = "Classificação de Triglicerídeos:\n" + classification;
    JOptionPane.showMessageDialog(null, message, "Resultado de Exame - Triglicerídeos", JOptionPane.INFORMATION_MESSAGE);
}

@Override
public void mostrarResultado() {
    super.mostrarResultado();
    classificarResultado();
}
}

